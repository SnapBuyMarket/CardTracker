
How to import this fix
----------------------
1) Open your `CardTracker.xlsm` and press ALT+F11 (VBA editor).
2) In the Project pane, expand "Modules".
3) **Right‑click the old `Module_eBayAPI` and choose Remove...** (click "No" when asked to export, unless you want a backup).
4) File → Import File... → select `Module_eBayAPI.bas` from this zip.
5) Save (CTRL+S) and close the VBA editor.
6) Back in Excel, click **Last 7 Days** or **Last 30 Days**.

What changed
------------
- `LoadSales` now loops every row on the **Search** sheet where column A = TRUE, using column B as the player/query.
- Optional Min/Max and Auction/BIN filters per row are supported (columns C–E).
- Removed the 25/50/100 caps logic so broad queries return results.
- Fixed `FirstNonEmpty` ParamArray type.
